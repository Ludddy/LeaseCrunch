USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_LeaseDetail_Insert]    Script Date: 1/8/2023 7:29:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[sp_LeaseDetail_Insert]
AS
BEGIN

	SELECT id.ID AS LeaseID,
		id.LeaseName, 
		imp.StartDate, 
		imp.EndDate, 
		imp.PaymentAmount,
		imp.NumberofPayments,
		imp.InterestRate,
		DateDIFF_BIG(MM, DateAdd(SECOND,0,imp.StartDate), DateAdd(SECOND,0,imp.EndDate)) AS NumberOfMonths,
		GETDATE() AS WriteDateTime 
	INTO #Temp_LeaseImportData
	FROM LeaseID AS id
	INNER JOIN Lease_Import_Data AS imp ON id.LeaseName = imp.LeaseName

	--INSERT INTO Lease_Import_Data
	INSERT INTO LeaseDetail
	SELECT DISTINCT *
	FROM #Temp_LeaseImportData

	--DELETE FROM interview_use_cases
	DROP TABLE #Temp_LeaseImportData

END
GO


