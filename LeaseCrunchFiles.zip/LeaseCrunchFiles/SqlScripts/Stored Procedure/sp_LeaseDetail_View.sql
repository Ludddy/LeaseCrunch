USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_LeaseDetail_View]    Script Date: 1/8/2023 7:30:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_LeaseDetail_View]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM LeaseDetail_View

	SELECT 
		l.ID,
		l.LeaseID,
		l.LeaseName,
		CONVERT(varchar(10), Cast(l.StartDate AS date), 101) AS StartDate,
		CONVERT(varchar(10), Cast(l.EndDate AS date), 101) AS EndDate,
		l.PaymentAmount, 
		l.NumberOfPayments,
		DATEDIFF(mm, l.StartDate, l.EndDate) AS NumberofMonths,
		Convert(varchar, l.InterestRate) + '%' AS InterestRate
		INTO #TempTable
	FROM LeaseDetail AS l
	WHERE l.NumberofMonths >= l.NumberOfPayments
		AND l.PaymentAmount > -1000000000 
		AND l.PaymentAmount < 1000000000
		AND l.NumberofPayments > 0
		AND l.NumberofPayments <= NumberofMonths
		AND InterestRate > 0
		AND InterestRate <= 9.99
	ORDER BY l.EndDate

	INSERT INTO LeaseDetail_View
	SELECT ID, LeaseID, LeaseName, StartDate, EndDate, PaymentAmount, NumberofPayments, InterestRate
	FROM #TempTable

	DROP TABLE #TempTable	
END
GO


