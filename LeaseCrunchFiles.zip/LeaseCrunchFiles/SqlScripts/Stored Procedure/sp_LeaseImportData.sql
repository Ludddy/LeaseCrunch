USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_LeaseImportData]    Script Date: 1/8/2023 7:31:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[sp_LeaseImportData]
AS
BEGIN

	SELECT [Name] AS LeaseName
		,DATEADD(MILLISECOND, 0,StartDate) AS StartDate
		,DATEADD(MILLISECOND, 0, EndDate) AS EndDate
		,ROUND(PaymentAmount, 2) AS PaymentAmount
		,NumberofPayments
		,InterestRate * 100 AS InterestRate
		,GETDATE() AS WriteDateTime
	INTO #Temp_LeaseImportData
	FROM [dbo].[interview_use_cases]

	DELETE FROM #Temp_LeaseImportData
	WHERE StartDate > EndDate
	OR EndDate < StartDate

	INSERT INTO Lease_Import_Data
	SELECT *
	FROM #Temp_LeaseImportData

	DELETE FROM interview_use_cases
	DROP TABLE #Temp_LeaseImportData
END
GO


