USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_PaymentHistoryCalandar_Processor]    Script Date: 1/8/2023 7:32:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_PaymentHistoryCalandar_Processor](
@LeaseID int
)

AS
BEGIN

----query test values
--DECLARE @LeaseID int
--SET @LeaseID = 8

DECLARE @ImportID int
DECLARE @StartDate datetime2(2)
DECLARE @EndDate Datetime2(2)
DECLARE @HistoryYearStart datetime2(2) 
DECLARE @HistoryYearEnd DateTime2
DECLARE @YearStartDate datetime2(2) 
DECLARE @YearEndDate DateTime2
DECLARE @FloatDate DateTime2(2)
DECLARE @NumberOfPayments int
DECLARE @sql Varchar(1000)

SET @ImportID = 0
-- Selects ImportID
IF NOT EXISTS(SELECT [ImportID] FROM PaymentHistoryCalandar)
	BEGIN
		SET @ImportID = 0
	END
ELSE
	BEGIN
			SELECT @ImportID = MAX(ImportID) + 1
			FROM PaymentHistoryCalandar
	END

--Gets Data From LeaseDetail table and assings variables
SELECT @StartDate = DATEADD(yyyy,0,StartDate)
	,@FloatDate = DATEADD(yyyy,0,StartDate)
	,@EndDate = DATEADD(yyyy,0,EndDate)
	,@HistoryYearStart = DATEADD(yyyy, DATEDIFF(yy, 0, StartDate), 0)
	,@HistoryYearEnd = DATEADD(yyyy, DATEDIFF(yy, 0, EndDate) + 1, -1)
	,@NumberOfPayments = NumberofPayments
FROM LeaseDetail
WHERE @LeaseID = LeaseID

--Loops through records between years, then months based on Date range for LeaseID 
WHILE (@FloatDate BETWEEN @HistoryYearStart AND @HistoryYearEnd) AND (@NumberOfPayments >= 0) 
	BEGIN 

	SET @YearStartDate = DATEADD(yyyy, DATEDIFF(yyyy, 0, @FloatDate), 0)
	SET @YearEndDate = DATEADD(yyyy, DATEDIFF(yyyy, 0, @FloatDate) + 1, -1)

		-- Asigns True or Fals for each Month in this year
		WHILE (DATEADD(yyyy,0,@FloatDate) BETWEEN DATEADD(yyyy,0,@YearStartDate) AND DATEADD(yyyy,0,@YearEndDate) 
			AND (DATEADD(yyyy,0,@YearStartDate) < DATEADD(yyyy,0,@EndDate)))
		BEGIN

			Declare @MonthCounter int
			SET @MonthCounter = 0

			-- create SQL Import string
			SET @sql = 'INSERT INTO PaymentHistoryCalandar ([ImportID], [LeaseID], [RecordYear], [Jan], [Feb], [Mar], [Apr], [May], [Jun], [Jul], [Aug], [Sep], [Oct], [Nov], [Dec]) VALUES (' + CONVERT(varchar(20), @ImportID)
			+', '+ CONVERT(varchar(10), @LeaseID)
			+', '+ CONVERT(varchar(4), @YearStartDate)

			-- loops through months
			WHILE (@MonthCounter <= 12) 
			BEGIN
				
				Set @MonthCounter = @MonthCounter + 1

				-- asigns true or false and increments month
				if (Convert(int,DATEPART(MM, @FloatDate)) = @MonthCounter) 
					AND (@FloatDate >= @StartDate) 
					AND (@NumberOfPayments > 0)
					BEGIN
						SET @sql = @sql + ', '+ CONVERT(varchar(2), 1)
						SET @NumberofPayments = @NumberofPayments - 1

						--SELECT @FloatDate AS FloatDate, Convert(int,DATEPART(MM, @FloatDate)) AS MonthInt,@MonthCounter AS MonthCounter , @NumberOfPayments AS NumberofPayments
						SET @FloatDate = DATEADD(MM, +1, @FloatDate)
					END
				ELSE
					BEGIN
						IF (@MonthCounter BETWEEN 1 AND 12)
						BEGIN
							SET @sql = @sql + ', 0'
							
							IF (@NumberOfPayments = 0)
							BEGIN
								SET @FloatDate = DATEADD(MM, +1, @FloatDate)
							END
						END
					END 
					;
			END

			SET @sql = @sql + ')'

			IF LEN(@Sql) > 1
				BEGIN
					EXEC (@sql)
				END
			--Empties @sql Variable
			SET @sql = ''
			SET @YearEndDate = DATEADD(yy,1,@YearEndDate)
			Set @YearStartDate = DATEADD(yy, 1,@YearStartDate)
			IF (@NumberOfPayments = 0) AND (DatePart(yyyy,@YearStartDate) + 1 > DATEPART(yyyy,@EndDate))
			BEGIN
				BREAK;
			END
		END
		IF (@NumberOfPayments = 0) AND (DatePart(yyyy,@YearStartDate) > DATEPART(yyyy,@EndDate))
			BEGIN
				BREAK;
			
			END
	END
END
GO


