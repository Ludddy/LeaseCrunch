USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_LeaseID_Insert]    Script Date: 1/8/2023 7:30:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[sp_LeaseID_Insert]

AS
BEGIN

	SET NOCOUNT ON;

	-- Fills LeaseID table with NEW ID, LeaseName
	INSERT INTO LeaseID
	SELECT t.LeaseName, GETDATE() AS WriteDateTime
	FROM Lease_Import_Data t
	WHERE NOT EXISTS(SELECT LeaseName FROM LeaseID WHERE LeaseName IS NOT NULL)
	AND t.LeaseName IS NOT NULL

END
GO


