USE [LeaseCrunchdb]
GO

/****** Object:  StoredProcedure [dbo].[sp_PaymentHistoryCalandar_Insert]    Script Date: 1/8/2023 7:31:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_PaymentHistoryCalandar_Insert]              

AS              
BEGIN 

DECLARE @LeaseID int

DECLARE calandar_cursor CURSOR FOR 

SELECT LeaseID
FROM LeaseDetail
WHERE ID IN(SELECT MAX(id) AS id
			FROM LeaseDetail 
			GROUP BY LeaseID)
Order BY LeaseID

OPEN calandar_cursor

FETCH NEXT 
FROM calandar_cursor INTO @LeaseID

WHILE (@@FETCH_STATUS <> -1)
	BEGIN
			-- any business logic + temp inseration 
			print 'Importing LeaseID' + CONVERT(varchar(2), @LeaseID)
			EXEC [dbo].[sp_PaymentHistoryCalandar_Processor] @LeaseID

		FETCH NEXT FROM calandar_cursor INTO @LeaseID
	END

	CLOSE calandar_cursor

	DEALLOCATE calandar_cursor
END
GO


