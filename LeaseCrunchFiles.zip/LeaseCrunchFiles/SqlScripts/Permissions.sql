USE [master]
GO

/****** Object:  Login [admin]    Script Date: 1/8/2023 7:18:40 PM ******/
DROP LOGIN [admin]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [admin]    Script Date: 1/8/2023 7:18:40 PM ******/
CREATE LOGIN [admin] WITH PASSWORD=N'tweu/+Kds7WCF/pAE6b78l5G3VDfGHbHSPmva90fpZg=', DEFAULT_DATABASE=[LeaseCrunchdb], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=ON, CHECK_POLICY=ON
GO

ALTER LOGIN [admin] DISABLE
GO

ALTER SERVER ROLE [sysadmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [securityadmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [serveradmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [setupadmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [processadmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [diskadmin] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [dbcreator] ADD MEMBER [admin]
GO

ALTER SERVER ROLE [bulkadmin] ADD MEMBER [admin]
GO


