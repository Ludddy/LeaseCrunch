USE [LeaseCrunchdb]
GO

/****** Object:  Table [dbo].[LeaseID]    Script Date: 1/8/2023 7:28:45 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LeaseID]') AND type in (N'U'))
DROP TABLE [dbo].[LeaseID]
GO

/****** Object:  Table [dbo].[LeaseID]    Script Date: 1/8/2023 7:28:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LeaseID](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[LeaseName] [varchar](50) NOT NULL,
	[WriteDateTime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


