USE [LeaseCrunchdb]
GO

/****** Object:  Table [dbo].[interview_use_cases]    Script Date: 1/8/2023 7:26:28 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[interview_use_cases]') AND type in (N'U'))
DROP TABLE [dbo].[interview_use_cases]
GO

/****** Object:  Table [dbo].[interview_use_cases]    Script Date: 1/8/2023 7:26:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[interview_use_cases](
	[Name] [varchar](50) NOT NULL,
	[StartDate] [datetime2](2) NOT NULL,
	[EndDate] [datetime2](2) NOT NULL,
	[PaymentAmount] [numeric](9, 2) NOT NULL,
	[NumberofPayments] [tinyint] NOT NULL,
	[InterestRate] [money] NOT NULL
) ON [PRIMARY]
GO


