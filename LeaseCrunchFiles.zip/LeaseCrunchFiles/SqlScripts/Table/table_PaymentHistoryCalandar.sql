USE [LeaseCrunchdb]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Dec__4A4E069C]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Nov__4959E263]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Oct__4865BE2A]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Sep__477199F1]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Aug__467D75B8]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Jul__4589517F]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Jun__44952D46]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__May__43A1090D]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Apr__42ACE4D4]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Mar__41B8C09B]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Feb__40C49C62]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHist__Jan__3FD07829]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] DROP CONSTRAINT [DF__PaymentHi__Impor__3EDC53F0]
GO

/****** Object:  Table [dbo].[PaymentHistoryCalandar]    Script Date: 1/8/2023 7:29:10 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentHistoryCalandar]') AND type in (N'U'))
DROP TABLE [dbo].[PaymentHistoryCalandar]
GO

/****** Object:  Table [dbo].[PaymentHistoryCalandar]    Script Date: 1/8/2023 7:29:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PaymentHistoryCalandar](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ImportID] [int] NOT NULL,
	[LeaseID] [int] NOT NULL,
	[RecordYear] [int] NOT NULL,
	[Jan] [bit] NOT NULL,
	[Feb] [bit] NOT NULL,
	[Mar] [bit] NOT NULL,
	[Apr] [bit] NOT NULL,
	[May] [bit] NOT NULL,
	[Jun] [bit] NOT NULL,
	[Jul] [bit] NOT NULL,
	[Aug] [bit] NOT NULL,
	[Sep] [bit] NOT NULL,
	[Oct] [bit] NOT NULL,
	[Nov] [bit] NOT NULL,
	[Dec] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [ImportID]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Jan]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Feb]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Mar]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Apr]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [May]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Jun]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Jul]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Aug]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Sep]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Oct]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Nov]
GO

ALTER TABLE [dbo].[PaymentHistoryCalandar] ADD  DEFAULT ((0)) FOR [Dec]
GO


