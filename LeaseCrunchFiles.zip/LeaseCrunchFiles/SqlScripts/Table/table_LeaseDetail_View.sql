USE [LeaseCrunchdb]
GO

/****** Object:  Table [dbo].[LeaseDetail_View]    Script Date: 1/8/2023 7:28:16 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LeaseDetail_View]') AND type in (N'U'))
DROP TABLE [dbo].[LeaseDetail_View]
GO

/****** Object:  Table [dbo].[LeaseDetail_View]    Script Date: 1/8/2023 7:28:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LeaseDetail_View](
	[ID] [int] NOT NULL,
	[LeaseID] [int] NOT NULL,
	[LeaseName] [varchar](50) NOT NULL,
	[StartDate] [varchar](10) NOT NULL,
	[EndDate] [varchar](10) NOT NULL,
	[PaymentAmount] [numeric](9, 2) NOT NULL,
	[NumberofPayments] [tinyint] NOT NULL,
	[InterestRate] [varchar](5) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


