USE [LeaseCrunchdb]
GO

/****** Object:  Table [dbo].[LeaseDetail]    Script Date: 1/8/2023 7:27:49 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LeaseDetail]') AND type in (N'U'))
DROP TABLE [dbo].[LeaseDetail]
GO

/****** Object:  Table [dbo].[LeaseDetail]    Script Date: 1/8/2023 7:27:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LeaseDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[LeaseID] [int] NOT NULL,
	[LeaseName] [varchar](50) NOT NULL,
	[StartDate] [datetime2](7) NOT NULL,
	[EndDate] [datetime2](7) NOT NULL,
	[PaymentAmount] [numeric](9, 2) NOT NULL,
	[NumberofPayments] [tinyint] NOT NULL,
	[InterestRate] [money] NOT NULL,
	[NumberofMonths] [int] NOT NULL,
	[WriteDateTime] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


