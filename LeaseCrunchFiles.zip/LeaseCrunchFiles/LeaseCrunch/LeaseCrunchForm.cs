﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.ComponentModel;

namespace LeaseCrunch
{
    public partial class LeaseCrunchForm : Form
    {
        public LeaseCrunchForm()
        {
            InitializeComponent();
        }

        private void LeaseCrunchForm_Load(object sender, EventArgs e)
        {
            tabPage_Calandar.Enabled = false;
            Fetch_dgv_LeaseDetail();
            Fetch_dgv_PaymentHistoryCalandar();
        }

        //private variables
        private OpenFileDialog ofd;

        private void btn_BrowseLease_Click(object sender, EventArgs e)
        {
            //file browser to only select .csv files
            BrowseLease();
        }

        private void BrowseLease()
        {
            //file browser to only select .csv files
            ofd = new OpenFileDialog();
            ofd.InitialDirectory = @"c:\";
            ofd.InitialDirectory = @"C:\Users\Lud\Downloads\LC-CodingChallenge-Revised\";
            ofd.Filter = "CSV files (*.csv)|*.csv";
            ofd.FilterIndex = 2;
            ofd.RestoreDirectory = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                tb_UploadLeaseFilePath.Text = ofd.FileName;
                btn_UploadLease.Enabled = true;
            }
            else
            {
                tb_UploadLeaseFilePath.Text = "Please select a valid .cvs file";
                btn_UploadLease.Enabled = false;
            }
        }

        private void btn_UploadLease_Click(object sender, EventArgs e)
        {
            string connString = "Data Source=(localdb)\\LeaseCrunch;Initial Catalog=LeaseCrunchdb;User ID=admin;Password=password";

            lblStatus.Text = "Fetching .csv file..."; lblStatus.Refresh(); Thread.Sleep(250);

            string filePath = tb_UploadLeaseFilePath.Text;
            lblStatus.Text = "Importing..."; lblStatus.Refresh(); Thread.Sleep(250);
            ProcessCSV(filePath, connString);
            Fetch_dgv_LeaseDetail();
            Fetch_dgv_PaymentHistoryCalandar();
            lblStatus.Text = "Complete!";
        }

        private void ProcessCSV(string filePath, string connString) 
        {
            DataTable dt = new DataTable();
            dt = GetDataTableFromCSVFile(filePath);

            lblStatus.Text = "Inserting Data..."; lblStatus.Refresh(); Thread.Sleep(250);
            InsertDataIntoSQLServerUsingSQLBulkCopy(dt, connString);

            lblStatus.Text = "Clenseing Data..."; lblStatus.Refresh(); Thread.Sleep(250);
            ImportDataClense(connString);

            lblStatus.Text = "Distributing Tables..."; lblStatus.Refresh(); Thread.Sleep(250);
            TableDistrabution(connString);
        }

        private static DataTable GetDataTableFromCSVFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column.Replace(@" ", ""));
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                                MessageBox.Show("Null Value in File.  Upload has Failed.  Please ensure all feilds contain data.");
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
            return csvData;
        }

        static void InsertDataIntoSQLServerUsingSQLBulkCopy(DataTable csvFileData,string connString)
        {
            SqlConnection dbConn = new SqlConnection(connString);
            using (dbConn)
            {
                dbConn.Open();
                using (SqlBulkCopy s = new SqlBulkCopy(dbConn))
                {
                    s.DestinationTableName = "interview_use_cases";
                    try
                    {
                        foreach (var column in csvFileData.Columns)
                            s.ColumnMappings.Add(column.ToString(), column.ToString());
                        s.WriteToServer(csvFileData);
                    }
                    catch
                    {
                        MessageBox.Show("Failed ot upload .csv file.");
                    }
                }
                dbConn.Close();
            }
        }

        static void ImportDataClense(string connString)
        {
            SqlConnection dbConn = new SqlConnection(connString);

            using (dbConn)
            {
                dbConn.Open();
                try { 
                    SqlCommand sqlCmd = new SqlCommand("Delete FROM [LeaseCrunchdb].dbo.[Lease_Import_Data]", dbConn);
                    sqlCmd.ExecuteNonQuery();

                    sqlCmd = new SqlCommand("exec dbo.sp_LeaseImportData", dbConn);
                    UIStatusUpdates(sqlCmd.ExecuteNonQuery(),"ImportDataClense");
                }
                catch
                {
                    MessageBox.Show("Failure at ImportDataClense Method");
                }
                dbConn.Close();
            }
        }

        static void TableDistrabution(string ConnString)
        {
            LeaseID(ConnString);
            LeaseDetail(ConnString);
            LeaseDetail_View(ConnString);
            PaymentHistoryCalandar(ConnString);
        }

        static void LeaseID(string ConnString)
        {
            SqlConnection dbConn = new SqlConnection(ConnString);

            using (dbConn)
            {
                dbConn.Open();
                try { 
                    SqlCommand sqlCmd = new SqlCommand("exec dbo.sp_LeaseID_Insert", dbConn);
                    sqlCmd.ExecuteNonQuery();
                }
                catch
                {
                    MessageBox.Show("Failure at LeaseID Method");
                }
                dbConn.Close();
            }
        }

        static void LeaseDetail(string ConnString)
        {
            SqlConnection dbConn = new SqlConnection(ConnString);

            using (dbConn)
            {
                dbConn.Open();
                try { 
                    SqlCommand sqlCmd = new SqlCommand("exec dbo.sp_LeaseDetail_Insert", dbConn);
                    UIStatusUpdates(sqlCmd.ExecuteNonQuery(),"LeaseDetail");
                }
                catch
                {
                    MessageBox.Show("Failure at LeaseDetail Method");
                }
                dbConn.Close();
            }
        }

        static void LeaseDetail_View(string ConnString)
        {
            SqlConnection dbConn = new SqlConnection(ConnString);

            using (dbConn)
            {
                dbConn.Open();
                try
                {
                    SqlCommand sqlCmd = new SqlCommand("exec dbo.sp_LeaseDetail_View", dbConn);
                    sqlCmd.ExecuteNonQuery();
                }
                    catch
                {
                    MessageBox.Show("Failure at LeaseDetail_View Method");
                }
            dbConn.Close();
            }
        }

        static void PaymentHistoryCalandar(string ConnString)
        {
            SqlConnection dbConn = new SqlConnection(ConnString);

            using (dbConn)
            {
                dbConn.Open();
                try
                {
                    SqlCommand sqlCmd = new SqlCommand("exec sp_PaymentHistoryCalandar_Insert", dbConn);
                    sqlCmd.ExecuteNonQuery();
                }
                catch
                {
                    MessageBox.Show("Failure at PaymentHistoryCalandar Method");
                }
                dbConn.Close();
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Fetch_dgv_LeaseDetail();
            Fetch_dgv_PaymentHistoryCalandar();
        }

        private void Fetch_dgv_LeaseDetail()
        {
            string sql = "SELECT * \r\nFROM LeaseDetail_View\r\nWHERE ID IN (SELECT MAX(ID) \r\n\t\t\tFROM LeaseDetail_View\r\n\t\t\tGROUP BY LeaseID) ";

            if (tb_Search.TextLength == 0)
            {
                dgv_LeaseDetails_FetchData(sql);
                tabPage_Calandar.Enabled = false;
            }
            else
            {
                int i = 0;
                if (int.TryParse(tb_Search.Text.ToString(), out i) == true)
                {
                    sql += "AND LeaseID = " + i.ToString();
                    dgv_LeaseDetails_FetchData(sql);
                    tabPage_Calandar.Enabled = true;
                }
                else
                {
                    tb_Search.Text = "";
                    MessageBox.Show("Please enter a valic LeaseID Or leave blank for all results.");
                }
            }
        }

        private void dgv_LeaseDetails_FetchData(string sql)
        {
            SqlConnection dbConn = new SqlConnection("Data Source=(localdb)\\LeaseCrunch;Initial Catalog=LeaseCrunchdb;User ID=admin;Password=password");
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, dbConn);
            DataSet ds = new DataSet();

            dbConn.Open();
            dataAdapter.Fill(ds, "LeaseDetail_View");
            dbConn.Close();

            dgv_LeaseDetail.DataSource = ds;
            dgv_LeaseDetail.DataMember = "LeaseDetail_View";
            dgv_LeaseDetail.AutoResizeColumns();
            dgv_LeaseDetail.Refresh();
        }

        private void dgv_PaymentHistoryCalandar_FetchData(string sql)
        {
            SqlConnection dbConn = new SqlConnection("Data Source=(localdb)\\LeaseCrunch;Initial Catalog=LeaseCrunchdb;User ID=admin;Password=password");
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, dbConn);
            DataSet ds = new DataSet();

            dbConn.Open();
            dataAdapter.Fill(ds, "PaymentHistoryCalandar");
            dbConn.Close();

            dgv_PaymentHistoryCalandar.DataSource = ds;
            dgv_PaymentHistoryCalandar.DataMember = "PaymentHistoryCalandar";
            dgv_PaymentHistoryCalandar.AutoResizeColumns();
            dgv_PaymentHistoryCalandar.Refresh();
        }

        private void Fetch_dgv_PaymentHistoryCalandar()
        {
            string sql = "SELECT *\r\nFROM PaymentHistoryCalandar\r\nWHERE ImportID IN(SELECT MAX(ImportID) AS id\r\n\t\t\tFROM PaymentHistoryCalandar \r\n\t\t\tGROUP BY LeaseID)";

            if (tb_Search.TextLength == 0)
            {
                sql += " Order By RecordYear ASC";
                dgv_PaymentHistoryCalandar_FetchData(sql);
                tabPage_Calandar.Enabled = false;
            }
            else
            {
                int i = 0;
                if (int.TryParse(tb_Search.Text.ToString(), out i) == true)
                {
                    sql += "AND LeaseID = " + i.ToString();
                    sql += " Order By RecordYear ASC";
                    dgv_PaymentHistoryCalandar_FetchData(sql);
                    tabPage_Calandar.Enabled = true;
                }
                else
                {
                    tb_Search.Text = "";
                    MessageBox.Show("Please enter a valic LeaseID Or leave blank for all results.");
                }
            }
        }

        private static void UIStatusUpdates(int i, string msg)
        {
            if (!(i > 0))
            {
                MessageBox.Show("No new Items added for " + msg + ".");
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_PurgeDB_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you Sure you want to Purge the Database?", "WARNGING!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                SqlConnection dbConn = new SqlConnection("Data Source=(localdb)\\LeaseCrunch;Initial Catalog=LeaseCrunchdb;User ID=admin;Password=password");

                using (dbConn)
                {
                    dbConn.Open();
                    SqlCommand sqlCmd = new SqlCommand("DELETE FROM interview_use_cases;\r\nDELETE FROM LeaseID;\r\nDELETE FROM Lease_Import_Data;\r\nDELETE FROM LeaseDetail;\r\nDELETE FROM LeaseDetail_View;\r\nDELETE FROM PaymentHistoryCalandar;\r\n", dbConn);
                    sqlCmd.ExecuteNonQuery();
                    dbConn.Close();
                }
                MessageBox.Show("Data Purged.");
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void dgv_LeaseDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rb_DetailsSortToggle.Checked == true)
            {
                this.dgv_LeaseDetail.Sort(this.dgv_LeaseDetail.Columns["StartDate"], ListSortDirection.Descending); 
                rb_DetailsSortToggle.Checked = false;

            }
            else
            {
                this.dgv_LeaseDetail.Sort(this.dgv_LeaseDetail.Columns["StartDate"], ListSortDirection.Ascending);
                rb_DetailsSortToggle.Checked = true;
            }            
        }

        private void dgv_PaymentHistoryCalandar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rb_Calandar.Checked == true)
            {
                this.dgv_PaymentHistoryCalandar.Sort(this.dgv_PaymentHistoryCalandar.Columns["RecordYear"], ListSortDirection.Descending);
                rb_Calandar.Checked = false;

            }
            else
            {
                this.dgv_LeaseDetail.Sort(this.dgv_PaymentHistoryCalandar.Columns["RecordYear"], ListSortDirection.Ascending);
                rb_Calandar.Checked = true;
            }
        }
    }
}
