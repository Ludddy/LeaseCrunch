﻿namespace LeaseCrunch
{
    partial class LeaseCrunchForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BrowseLease = new System.Windows.Forms.Button();
            this.tb_UploadLeaseFilePath = new System.Windows.Forms.TextBox();
            this.btn_UploadLease = new System.Windows.Forms.Button();
            this.pb1 = new System.Windows.Forms.ProgressBar();
            this.lblStatus = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_LeaseDetails = new System.Windows.Forms.TabPage();
            this.dgv_LeaseDetail = new System.Windows.Forms.DataGridView();
            this.tabPage_Calandar = new System.Windows.Forms.TabPage();
            this.dgv_PaymentHistoryCalandar = new System.Windows.Forms.DataGridView();
            this.btn_PurgeDB = new System.Windows.Forms.Button();
            this.tb_Search = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_LeaseID = new System.Windows.Forms.Label();
            this.pb2 = new System.Windows.Forms.ProgressBar();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rb_DetailsSortToggle = new System.Windows.Forms.RadioButton();
            this.rb_Calandar = new System.Windows.Forms.RadioButton();
            this.tabControl1.SuspendLayout();
            this.tabPage_LeaseDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_LeaseDetail)).BeginInit();
            this.tabPage_Calandar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PaymentHistoryCalandar)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_BrowseLease
            // 
            this.btn_BrowseLease.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_BrowseLease.Location = new System.Drawing.Point(12, 27);
            this.btn_BrowseLease.Name = "btn_BrowseLease";
            this.btn_BrowseLease.Size = new System.Drawing.Size(116, 23);
            this.btn_BrowseLease.TabIndex = 0;
            this.btn_BrowseLease.Text = "Browse Lease";
            this.btn_BrowseLease.UseVisualStyleBackColor = true;
            this.btn_BrowseLease.Click += new System.EventHandler(this.btn_BrowseLease_Click);
            // 
            // tb_UploadLeaseFilePath
            // 
            this.tb_UploadLeaseFilePath.Location = new System.Drawing.Point(134, 27);
            this.tb_UploadLeaseFilePath.Name = "tb_UploadLeaseFilePath";
            this.tb_UploadLeaseFilePath.ReadOnly = true;
            this.tb_UploadLeaseFilePath.Size = new System.Drawing.Size(641, 23);
            this.tb_UploadLeaseFilePath.TabIndex = 1;
            this.tb_UploadLeaseFilePath.Text = "C:\\Users\\Lud\\Downloads\\LC-CodingChallenge-Revised\\interview_use_cases_Test.csv";
            // 
            // btn_UploadLease
            // 
            this.btn_UploadLease.Enabled = false;
            this.btn_UploadLease.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_UploadLease.Location = new System.Drawing.Point(12, 56);
            this.btn_UploadLease.Name = "btn_UploadLease";
            this.btn_UploadLease.Size = new System.Drawing.Size(116, 23);
            this.btn_UploadLease.TabIndex = 2;
            this.btn_UploadLease.Text = "Upload Lease";
            this.btn_UploadLease.UseVisualStyleBackColor = true;
            this.btn_UploadLease.Click += new System.EventHandler(this.btn_UploadLease_Click);
            // 
            // pb1
            // 
            this.pb1.Location = new System.Drawing.Point(134, 56);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(641, 23);
            this.pb1.TabIndex = 3;
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Location = new System.Drawing.Point(343, 60);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(200, 15);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "lblStatus";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_LeaseDetails);
            this.tabControl1.Controls.Add(this.tabPage_Calandar);
            this.tabControl1.Location = new System.Drawing.Point(12, 108);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(767, 427);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage_LeaseDetails
            // 
            this.tabPage_LeaseDetails.Controls.Add(this.dgv_LeaseDetail);
            this.tabPage_LeaseDetails.Location = new System.Drawing.Point(4, 24);
            this.tabPage_LeaseDetails.Name = "tabPage_LeaseDetails";
            this.tabPage_LeaseDetails.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_LeaseDetails.Size = new System.Drawing.Size(759, 399);
            this.tabPage_LeaseDetails.TabIndex = 0;
            this.tabPage_LeaseDetails.Text = "Lease Details";
            this.tabPage_LeaseDetails.UseVisualStyleBackColor = true;
            // 
            // dgv_LeaseDetail
            // 
            this.dgv_LeaseDetail.AllowUserToAddRows = false;
            this.dgv_LeaseDetail.AllowUserToDeleteRows = false;
            this.dgv_LeaseDetail.AllowUserToOrderColumns = true;
            this.dgv_LeaseDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_LeaseDetail.Location = new System.Drawing.Point(0, 0);
            this.dgv_LeaseDetail.Name = "dgv_LeaseDetail";
            this.dgv_LeaseDetail.ReadOnly = true;
            this.dgv_LeaseDetail.RowTemplate.Height = 25;
            this.dgv_LeaseDetail.Size = new System.Drawing.Size(759, 399);
            this.dgv_LeaseDetail.TabIndex = 0;
            this.dgv_LeaseDetail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_LeaseDetail_CellContentClick);
            // 
            // tabPage_Calandar
            // 
            this.tabPage_Calandar.Controls.Add(this.dgv_PaymentHistoryCalandar);
            this.tabPage_Calandar.Location = new System.Drawing.Point(4, 24);
            this.tabPage_Calandar.Name = "tabPage_Calandar";
            this.tabPage_Calandar.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Calandar.Size = new System.Drawing.Size(759, 399);
            this.tabPage_Calandar.TabIndex = 1;
            this.tabPage_Calandar.Text = "Calandar";
            this.tabPage_Calandar.UseVisualStyleBackColor = true;
            // 
            // dgv_PaymentHistoryCalandar
            // 
            this.dgv_PaymentHistoryCalandar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PaymentHistoryCalandar.Location = new System.Drawing.Point(0, 0);
            this.dgv_PaymentHistoryCalandar.Name = "dgv_PaymentHistoryCalandar";
            this.dgv_PaymentHistoryCalandar.ReadOnly = true;
            this.dgv_PaymentHistoryCalandar.RowTemplate.Height = 25;
            this.dgv_PaymentHistoryCalandar.Size = new System.Drawing.Size(759, 399);
            this.dgv_PaymentHistoryCalandar.TabIndex = 0;
            this.dgv_PaymentHistoryCalandar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_PaymentHistoryCalandar_CellContentClick);
            // 
            // btn_PurgeDB
            // 
            this.btn_PurgeDB.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_PurgeDB.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_PurgeDB.Location = new System.Drawing.Point(650, 541);
            this.btn_PurgeDB.Name = "btn_PurgeDB";
            this.btn_PurgeDB.Size = new System.Drawing.Size(129, 24);
            this.btn_PurgeDB.TabIndex = 0;
            this.btn_PurgeDB.Text = "Purge Database";
            this.btn_PurgeDB.UseVisualStyleBackColor = true;
            this.btn_PurgeDB.Click += new System.EventHandler(this.btn_PurgeDB_Click);
            // 
            // tb_Search
            // 
            this.tb_Search.Location = new System.Drawing.Point(586, 85);
            this.tb_Search.Name = "tb_Search";
            this.tb_Search.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tb_Search.Size = new System.Drawing.Size(58, 23);
            this.tb_Search.TabIndex = 6;
            // 
            // btn_Search
            // 
            this.btn_Search.Location = new System.Drawing.Point(650, 85);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(126, 23);
            this.btn_Search.TabIndex = 7;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_LeaseID
            // 
            this.lbl_LeaseID.AutoSize = true;
            this.lbl_LeaseID.Location = new System.Drawing.Point(524, 88);
            this.lbl_LeaseID.Name = "lbl_LeaseID";
            this.lbl_LeaseID.Size = new System.Drawing.Size(56, 15);
            this.lbl_LeaseID.TabIndex = 8;
            this.lbl_LeaseID.Text = "Lease ID :";
            // 
            // pb2
            // 
            this.pb2.Location = new System.Drawing.Point(12, 541);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(632, 23);
            this.pb2.TabIndex = 9;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(789, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(178, 22);
            this.toolStripMenuItem1.Text = "ITFluid@Gmail.com";
            // 
            // rb_DetailsSortToggle
            // 
            this.rb_DetailsSortToggle.AutoSize = true;
            this.rb_DetailsSortToggle.Location = new System.Drawing.Point(450, 89);
            this.rb_DetailsSortToggle.Name = "rb_DetailsSortToggle";
            this.rb_DetailsSortToggle.Size = new System.Drawing.Size(31, 19);
            this.rb_DetailsSortToggle.TabIndex = 11;
            this.rb_DetailsSortToggle.TabStop = true;
            this.rb_DetailsSortToggle.Text = "1";
            this.rb_DetailsSortToggle.UseVisualStyleBackColor = true;
            this.rb_DetailsSortToggle.Visible = false;
            // 
            // rb_Calandar
            // 
            this.rb_Calandar.AutoSize = true;
            this.rb_Calandar.Location = new System.Drawing.Point(487, 89);
            this.rb_Calandar.Name = "rb_Calandar";
            this.rb_Calandar.Size = new System.Drawing.Size(31, 19);
            this.rb_Calandar.TabIndex = 12;
            this.rb_Calandar.TabStop = true;
            this.rb_Calandar.Text = "2";
            this.rb_Calandar.UseVisualStyleBackColor = true;
            this.rb_Calandar.Visible = false;
            // 
            // LeaseCrunchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(789, 575);
            this.Controls.Add(this.rb_Calandar);
            this.Controls.Add(this.rb_DetailsSortToggle);
            this.Controls.Add(this.btn_PurgeDB);
            this.Controls.Add(this.pb2);
            this.Controls.Add(this.lbl_LeaseID);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_Search);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.btn_UploadLease);
            this.Controls.Add(this.tb_UploadLeaseFilePath);
            this.Controls.Add(this.btn_BrowseLease);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "LeaseCrunchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LeaseCrunch App";
            this.Load += new System.EventHandler(this.LeaseCrunchForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_LeaseDetails.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_LeaseDetail)).EndInit();
            this.tabPage_Calandar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PaymentHistoryCalandar)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_BrowseLease;
        private System.Windows.Forms.TextBox tb_UploadLeaseFilePath;
        private System.Windows.Forms.Button btn_UploadLease;
        private System.Windows.Forms.ProgressBar pb1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_LeaseDetails;
        private System.Windows.Forms.DataGridView dgv_LeaseDetail;
        private System.Windows.Forms.TabPage tabPage_Calandar;
        private System.Windows.Forms.DataGridView dgv_PaymentHistoryCalandar;
        private System.Windows.Forms.TextBox tb_Search;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Label lbl_LeaseID;
        private System.Windows.Forms.ProgressBar pb2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Button btn_PurgeDB;
        private System.Windows.Forms.RadioButton rb_DetailsSortToggle;
        private System.Windows.Forms.RadioButton rb_Calandar;
    }
}
